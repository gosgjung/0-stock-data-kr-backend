rootProject.name = "earning_api"
