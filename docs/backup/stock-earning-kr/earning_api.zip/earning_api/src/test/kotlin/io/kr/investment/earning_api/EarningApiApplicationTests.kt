package io.kr.investment.earning_api

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class EarningApiApplicationTests {

	@Test
	fun contextLoads() {
	}

}
