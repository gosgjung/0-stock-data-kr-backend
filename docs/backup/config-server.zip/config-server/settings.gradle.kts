rootProject.name = "config-server"
