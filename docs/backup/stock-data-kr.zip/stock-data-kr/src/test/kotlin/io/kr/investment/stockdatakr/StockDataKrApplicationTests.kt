package io.kr.investment.stockdatakr

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class StockDataKrApplicationTests {

	@Test
	fun contextLoads() {
	}

}
