package io.kr.investment.stockdatakr

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class StockDataKrApplication

fun main(args: Array<String>) {
	runApplication<StockDataKrApplication>(*args)
}
