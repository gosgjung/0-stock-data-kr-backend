rootProject.name = "stock-data-kr"
